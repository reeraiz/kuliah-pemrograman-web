// Daftar produk (bisa nanti diambil dari API / DB)
const products = [
  { id: 1, name: "Nasi Box Premium", price: 25000, image: "https://via.placeholder.com/200" },
  { id: 2, name: "Snack Box", price: 15000, image: "https://via.placeholder.com/200" },
  { id: 3, name: "Nasi Tumpeng Mini", price: 35000, image: "https://via.placeholder.com/200" },
  { id: 4, name: "Paket Prasmanan", price: 50000, image: "https://via.placeholder.com/200" },
];

let cart = [];

// Render produk hanya jika container ada
const productContainer = document.getElementById("productContainer");
if (productContainer) {
  products.forEach(p => {
    const el = document.createElement("div");
    el.className = "bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition";
    el.innerHTML = `
      <img src="${p.image}" alt="${p.name}" class="w-full h-48 object-cover">
      <div class="p-4">
        <h3 class="text-lg font-bold mb-2">${p.name}</h3>
        <p class="text-pink-600 font-semibold mb-3">Rp${p.price.toLocaleString()}</p>
        <button onclick="addToCart(${p.id})" class="bg-pink-600 hover:bg-pink-700 text-white w-full py-2 rounded-lg font-bold">
          Tambah ke Keranjang
        </button>
      </div>
    `;
    productContainer.appendChild(el);
  });
}

// Toggle cart modal
function toggleCart() {
  document.getElementById("cartModal").classList.toggle("hidden");
}

// Tambah ke keranjang
function addToCart(id) {
  const product = products.find(p => p.id === id);
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ ...product, qty: 1 });
  }
  updateCart();
}

// Update tampilan keranjang
function updateCart() {
  const cartItems = document.getElementById("cartItems");
  const cartCount = document.getElementById("cartCount");
  const cartTotal = document.getElementById("cartTotal");

  let total = 0;
  if (cartItems) cartItems.innerHTML = "";

  cart.forEach(item => {
    total += item.price * item.qty;
    if (cartItems) {
      const li = document.createElement("li");
      li.className = "flex justify-between items-center border-b pb-2";
      li.innerHTML = `
        <div>
          <p class="font-bold">${item.name}</p>
          <p class="text-sm text-gray-600">Rp${item.price.toLocaleString()} x ${item.qty}</p>
        </div>
        <button onclick="removeFromCart(${item.id})" class="text-red-600 hover:underline">Hapus</button>
      `;
      cartItems.appendChild(li);
    }
  });

  if (cartCount) cartCount.textContent = cart.length;
  if (cartTotal) cartTotal.textContent = `Rp${total.toLocaleString()}`;
}

// Hapus item dari keranjang
function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  updateCart();
}

// Checkout sederhana
function checkout() {
  if (cart.length === 0) {
    alert("Keranjang masih kosong!");
    return;
  }
  alert("Terima kasih sudah berbelanja!");
  cart = [];
  updateCart();
  toggleCart();
}
